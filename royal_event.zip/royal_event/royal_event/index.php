<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $sql = "SELECT * FROM tbladmin WHERE UserName=:username and Password=:password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':username', $username, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);
    if ($query->rowCount() > 0) {
        foreach ($results as $result) {
            $_SESSION['odmsaid'] = $result->ID;
            $_SESSION['login'] = $result->username;
            $_SESSION['permission'] = $result->AdminName;
            $get = $result->Status;
        }
        $aa = $_SESSION['odmsaid'];
        $sql = "SELECT * from tbladmin where ID=:aa";
        $query = $dbh->prepare($sql);
        $query->bindParam(':aa', $aa, PDO::PARAM_STR);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);
        if ($query->rowCount() > 0) {
            foreach ($results as $row) {
                if ($row->Status == "1") {
                    echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
                } else {
                    echo "<script>alert('Your account was disabled. Approach Admin'); document.location ='index.php';</script>";
                }
            }
        }
    } else {
        echo "<script>alert('Invalid Details');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .background {
            background: url('https://cdn.prod.website-files.com/63d06722a6f6c82db2e3292f/666c51af6acd91f2fb58d71e_Outdoor%20party%20with%20lamp%20garlands%20and%20many%20people%20silhouettes%2C%20blurred%20background.jpeg') 
                no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            color: #fff;
            text-align: center;
            width: 350px;
        }

        .login-box img {
            width: 280px;
            height: 80px;
            border-radius: 50%;
            margin-bottom: 20px;
        }


        .login-box h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .login-box p {
            margin-bottom: 20px;
        }

        .login-box label {
            display: block;
            text-align: left;
            margin-bottom: 5px;
            font-size: 14px;
        }

        .login-box input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
        }

        .login-box button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .login-box button:hover {
            background-color: #333;
        }

        .login-box a {
            color: #cce;
            text-decoration: none;
        }

        .login-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="background">
        <div class="login-box">
        <img src="assets/images/event logo-Photoroom.png" alt="Admin Avatar"><p>EVENT MANAGEMENT</p>
            <h1>Welcome Administrator!</h1>
            
            
            <form method="post" enctype="multipart/form-data">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <button type="submit" name="login">Sign In</button>
                <p><a href="forgot_password.php">Forgot Password?</a></p>
            </form>
        </div>
    </div>
</body>

</html>
